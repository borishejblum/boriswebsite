
<!-- README.md is generated from README.Rmd. Please edit that file -->
<!-- badges: start -->

[![R-CMD-check](https://github.com/borishejblum/mypkgr/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/borishejblum/mypkgr/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

# mypkgr

The goal of mypkgr is to test test test

## Installation

You can install mypkgr from github with:

``` r
# install.packages("remotes")
remotes::install_github("borishejblum/mypkgr")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
## basic example code
```
