
<!-- README.md is generated from README.Rmd. Please edit that file -->

# mypkgr

The goal of mypkgr is to work \!

You can install mypkgr from github with:

``` r
# install.packages("devtools")
devtools::install_github("borishejblum/mypkgr")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
## basic example code
```
