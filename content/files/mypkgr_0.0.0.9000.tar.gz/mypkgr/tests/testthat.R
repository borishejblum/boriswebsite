library(testthat)
library(mypkgr)

test_check("mypkgr")
