#' mypkgr.
#'
#' This the place to speak about your package.
#'
#' What is in the package...
#'
#' What are the most important functions...
#'
#' @name mypkgr
#' @docType package
#'
#' @useDynLib mypkgr, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#'
NULL
